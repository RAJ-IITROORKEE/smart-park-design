# SmartPark Rev D — case print files

This archive contains individual, millimetre STL and mesh-3MF files. All parts sit on Z=0 in their print orientation. These are first-article pilot parts, not printer-specific G-code.

Print base, lid, sensor_mask, sensor_retainer and light_pipe for either version. Add front_blank for the status-only product. For OLED, use front_oled plus oled_retainer instead. Print fit_coupon first to check transducer apertures and latch-window dimensions; use the actual lid to test clip flexibility.

Use PETG, starting at 0.2mm layers, 0.4mm nozzle, four perimeters, five top/bottom layers and 30% infill. The lid is inverted with its outside face on the bed. Review local supports under the base's front/USB opening roofs and mounting ears. Keep supports out of latch gaps. Use clear PETG or a 3mm light rod for the indicator.

Closed body:70x66x50.4mm;94mm wide with ears. Four mounting holes are4.5mm at82x42mm spacing. Battery reference:protected1S51x34x5mm over1mm foam; do not compress the pouch. Sensor mask assumes16mm cans at26mm pitch; measure your HC-SR04 before batch printing. It hides the sensor PCB while exposing the two faces downward.

For the electronics stack use8.5mm female sockets plus2.5mm male shoulders with a0.6mm air gap above the male plastic. A removable soldering shim sets the gap; remove it afterward. Male short legs must be at least3mm. This clears XIAO USB anchors and gives11.6mm carrier-to-XIAO separation. The full design package contains the detailed assembly guide, PCB, pin map and native CAD.

See docs/PRINT_CHECK.md and the included cad/checks/dfam reports for measurements. All nine meshes passed closure, positive-volume and millimetre-unit checks. Physical fit, shrinkage, latch life and ceiling attachment require a prototype. The enclosure is indoor-only with no IP rating. The reports' isolated thin-edge samples and support estimates still require slicer review.
